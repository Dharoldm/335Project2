/**
 * \file ActorFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "stdafx.h"
#include "ActorFactory.h"

/** \brief Constructor */
CActorFactory::CActorFactory()
{
}


/** \brief Destructor */
CActorFactory::~CActorFactory()
{
}
